
  # Create Seoro HUD Page

  This is a code bundle for Create Seoro HUD Page. The original project is available at https://www.figma.com/design/rMQJeuDfgFJhxyQD1n7EMh/Create-Seoro-HUD-Page.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  